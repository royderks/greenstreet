<?php

/* 
 * Roy Derks - hello@hackteam.io
 * MobilityHacks 2016
 * 
 */

include_once 'functions.php';


echo '<h1>List points</h1>';

$points = callAPI('points?transform=1');

//print_r($points);

foreach($points as $key => $point){
    
    foreach($point as $item) {
        
       $timestamp = $item['timestamp'];
       
       $route = callAPI('route?filter=timestamp,eq,' . $timestamp . '&transform=1');

       print_r($route);
       
    }
    
}
        
       