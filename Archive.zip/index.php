<html>
    <head>
        <script type="text/javascript" src="js/jquery-2.0.0.min.js"></script>
        
        <?php
        $points = 0;
        ?>
        <style type="text/css">
            
            @font-face{
    font-family: LeagueGothic;
    src: url(fonts/LeagueGothic-Regular.otf);
            }
            
            body{
                font-family: 'LeagueGothic';
                background: linear-gradient(powderblue,aliceblue);
            }
            
            h3{
                font-size: 2em;
                letter-spacing: 2px;
            }

            #box{
                text-align: center;
                position: absolute;
                padding: 5px;
                top: 10px;
                left: 50%;
                height: auto;
                width: 300px;
                transform: translate3d(-50%,0,0);
                border: 1px solid black;
                background: white;
            }
            #leaf-box{
                position: relative;
                background: white;
                left: 50%;
                top:0px;
                transform: translate3d(-50%,0,0);
                width: 100px;
                height: 300px;
            }
            #leaf{
                background: linear-gradient(limegreen,green);
                position: absolute;
                bottom: 0px;
                left: 50%;
                transform: translate3d(-50%,0,0);
                width: 100%;
                height:0;
                z-index: 0;
            }
            #img{
                z-index: 4;
                position: absolute;
                left: 0px;
                top: 0px;
                width: 100px;
                height: 300px;
            }
            h4{
                font-size: 1.5em;
                border: 1px solid green;
                border-top-color:darkseagreen;
                border-bottom-color: darkgreen;
                position: relative;
                background: rgba(255,255,255,0.6)
            }

            a{
                color: black;
            }
            a:hover{
                color: black;
            }
            
        </style>
    </head>
    <body>

      <div id="box"><h3>Green Street</h3>
          <?php
                include('leaf.php'); 
          ?>
          <br><br><br><br><br><br>
       <h4><a>Details</a></h4>
        <h4 id="start">Start</h4>
        </div>
        <script>
          $(document).ready(function() {
            $('#start').click(function() {
                var total = 0;
                var score = [1,0,1,1,1,-1,0,1,0]; 
                var i = 0, howManyTimes = score.length;
                
                function f() {
                    total += score[i];
                    console.log(total);
                    if(score[i] != 0)
                        $("#leaf").css("height",total*20 + "%"); 
   
                    i++;
                    if( i < howManyTimes ){
                    setTimeout( f, 1000 );
                    }
                }
                f();
         

            });
        }); 
        </script>

        
    </body>
</html>